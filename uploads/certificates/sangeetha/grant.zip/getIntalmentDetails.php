<?php
@session_start();
include 'ajaxconfig.php';

if(isset($_SESSION["userid"])){
    $userid = $_SESSION["userid"];
}

if(isset($_POST["institute_id"])){
	$institute_id = $_POST["institute_id"];
}

$instalment_agree = '';

// get instalment
$getInstalName=$con->query("SELECT instalment_agree FROM institute_creation WHERE institute_id = '".$institute_id."' ");

while($row3=$getInstalName->fetch_assoc()){

    $instalment_agree = $row3["instalment_agree"];
   
    }

$minimumrequirementName["instalment_agree"] = $instalment_agree;

 
echo json_encode($minimumrequirementName);
?>
<?php
@session_start();
include('ajaxconfig.php');

if(isset($_SESSION["userid"])){
    $userid = $_SESSION["userid"];
}

$column = array(
    'payment_entry_id',
    'voucher_ref',
    'institute_name',
    'applicant_name',
    'date_of_entry',
    'debit_ledger',
    'debit_amount',
    'credit_ledger',
    'credit_amount',
    'narration',
    'status'
);

$query = "SELECT * FROM payment_entry WHERE 1";

if($_POST['search']!="");
{
    if (isset($_POST['search'])) {

        if($_POST['search']=="Active")
        {
            $query .="and status=0 "; 
        }
        else if($_POST['search']=="Inactive")
        {
            $query .="and status=1 ";
        }

        else {	
            $query .= "
            and voucher_ref LIKE '%".$_POST['search']."%'
            or institute_name LIKE '%".$_POST['search']."%'
            or applicant_name LIKE '%".$_POST['search']."%'
            OR date_of_entry LIKE '%".$_POST['search']."%'
            OR debit_ledger LIKE '%".$_POST['search']."%'
            OR debit_amount LIKE '%".$_POST['search']."%'
            OR credit_ledger LIKE '%".$_POST['search']."%'
            OR credit_amount LIKE '%".$_POST['search']."%'
            OR narration LIKE '%".$_POST['search']."%'
            OR status LIKE '%".$_POST['search']."%' ";
        }
    }
}

if (isset($_POST['order'])) {
    $query .= 'ORDER BY ' . $column[$_POST['order']['0']['column']] . ' ' . $_POST['order']['0']['dir'] . ' ';
} else {
    $query .= ' ';
}

$query1 = '';

if ($_POST['length'] != -1) {
    $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

$statement = $connect->prepare($query);
$statement->execute();
$number_filter_row = $statement->rowCount();
$statement = $connect->prepare($query . $query1);
$statement->execute();
$result = $statement->fetchAll();
$data = array();

$sno = 1;
foreach ($result as $row) {
    $sub_array   = array();
    
    if($sno!="")
    {
        $sub_array[] = $sno;
    }
	
    $sub_array[] = $row['voucher_ref'];

     // fetch institute name
     $instituteName = $row['institute_name'];
     $getqry = "SELECT institute_name FROM institute_creation WHERE institute_id ='".strip_tags($instituteName)."' and status = 0";
     $res12 = $con->query($getqry);
     while($row12 = $res12->fetch_assoc())
     {
        $institute_name = $row12["institute_name"];        
     }


    // fetch applicant name
    $applicantName = $row['applicant_name']; 
    $getqry1 = "SELECT applicant_name FROM initiate_application WHERE application_id ='".strip_tags($applicantName)."' and status = 0";
    $res13 = $con->query($getqry1);
    while($row13 = $res13->fetch_assoc())
    {
       $applicant_name = $row13["applicant_name"];        
    }

    $sub_array[] = $institute_name;
    $sub_array[] = $applicant_name;
    $sub_array[] = $row['date_of_entry'];
    $sub_array[] = $row['debit_ledger'];
    $sub_array[] = $row['debit_amount'];
    $credit_ledger = $row['credit_ledger'];

    if($credit_ledger == 16){
        $creditName = 'Cash-in-hand';
    }else{
        $creditName = 'Bank Accounts';
    }

    $sub_array[] = $creditName;
    $sub_array[] = $row['credit_amount'];
    $sub_array[] = $row['narration'];
    $status      = $row['status'];

    if($status == 1)
	{
	$sub_array[] = "<span style='width: 144px;'><span class='kt-badge  kt-badge--danger kt-badge--inline kt-badge--pill'>Inactive</span></span>";
	}
	else
	{
    $sub_array[] = "<span style='width: 144px;'><span class='kt-badge  kt-badge--success kt-badge--inline kt-badge--pill'>Active</span></span>";
	}
	$id          = $row['payment_entry_id'];
	
	$action="<a href='payment_entry&upd=$id' title='Edit details'><span class='icon-border_color'></span></a>&nbsp;&nbsp; 
	<a href='payment_entry&del=$id' title='Delete details' class='delete_investment'><span class='icon-trash-2'></span></a>";

	$sub_array[] = $action;
    $data[]      = $sub_array;
    $sno         = $sno + 1;
} 

function count_all_data($connect)
{
    $query     = "SELECT * FROM payment_entry where status = '0' ";
    $statement = $connect->prepare($query);
    $statement->execute();
    return $statement->rowCount();
}

$output = array(
    'draw' => intval($_POST['draw']),
    'recordsTotal' => count_all_data($connect),
    'recordsFiltered' => $number_filter_row,
    'data' => $data
);

echo json_encode($output);
?>
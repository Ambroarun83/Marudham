<?php
@session_start(); 
include 'ajaxconfig.php';

if(isset($_SESSION["userid"])){
    $userid = $_SESSION["userid"];
}
if(isset($_POST["application_id"])){
	$application_id = $_POST["application_id"];
}

 
$course_name = '';
$course_fees = '';
$institute_id = array();
$institute_name = array();
$course_completion = '';
$instalment_agree = '';
$applicant_name = '';
$email_id = '';
$certificate = '';


// get minimum requirement name
$getMinReq=$con->query("SELECT * FROM `initiate_application` join course_creation on (course_creation.course_id=initiate_application.course_required_to_appear) WHERE application_id = '".$application_id."' ");
	while($row=$getMinReq->fetch_assoc()){
    $course_name    = $row["course_name"];
    $course_fees    = $row["course_fees"];
    $course_completion = $row["course_completion"];
    $applicant_name = $row["applicant_name"];
    $email_id = $row["email_id"];
     // $s_array = explode(",",$row['certificate']);
    $certificate = $row["certificate"];
}

// get institute name
$getInstName=$con->query("SELECT * FROM `initiate_application` JOIN institute_creation ON(institute_creation.institute_id=initiate_application.institute_like_to_appear) WHERE application_id ='".$application_id."' ");

	while($row2=$getInstName->fetch_assoc()){
    $institute_id[]    = $row2["institute_id"];
    $institute_name[]    = $row2["institute_name"];
    $instalment_agree = $row2["instalment_agree"];
}


$minimumrequirementName["institute_id"] = $institute_id;
$minimumrequirementName["institute_name"] = $institute_name;
$minimumrequirementName["instalment_agree"] = $instalment_agree;

$minimumrequirementName["course_name"] = $course_name;
$minimumrequirementName["course_fees"] = $course_fees;
$minimumrequirementName["course_completion"] = $course_completion;
$minimumrequirementName["applicant_name"] = $applicant_name;
$minimumrequirementName["email_id"] = $email_id;

$minimumrequirementName["certificate"] = $certificate;

 
echo json_encode($minimumrequirementName);
?>
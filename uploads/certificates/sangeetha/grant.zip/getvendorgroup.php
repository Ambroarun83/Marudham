<?php
include 'ajaxconfig.php';

if(isset($_POST["subgroup"])){
	$subgroup=$_POST["subgroup"];
}
$AccountsName="";
$getqry="SELECT ParentId,AccountsName FROM accountsgroup WHERE Id='".strip_tags($subgroup)."' and status=0";

$res=$con->query($getqry);
while ($row=$res->fetch_assoc()){
	$ParentId           = $row["ParentId"];
	$AccountsName       = $row["AccountsName"];
	if(	$ParentId > 0)
	{
		$getqry1="SELECT AccountsName, Id FROM accountsgroup WHERE Id='".strip_tags($ParentId)."' and status=0";
		$res1=$con->query($getqry1);
		while ($row1=$res1->fetch_assoc()){	
			$group["accountsname"]       = $row1["AccountsName"];
			$group["id"]                 = $row1["Id"];
		}
	}
}
echo json_encode($group);
?>

<?php
@session_start();
include 'ajaxconfig.php';

if(isset($_SESSION["userid"])){
    $userid = $_SESSION["userid"];
}
if(isset($_POST["application_id"])){
	$application_id = $_POST["application_id"];
}



$course_name = '';
$course_fees = '';
$institute_id = '';
$institute_name = '';
$course_completion = '';
$instalment_agree = '';
$instalment_start_date = '';
$instalment_end_date = '';
$batch_start_date = '';
$com_person1 = '';
$com_person2 = '';
$ins_person1 = '';
$applicant_name = '';
$email_id = '';
$ins_email_id = '';


// get minimum requirement name
$getMinReq=$con->query("SELECT * FROM `initiate_application` join course_creation on (course_creation.course_id=initiate_application.course_required_to_appear) WHERE application_id = '".$application_id."' ");
while($row=$getMinReq->fetch_assoc()){
    $course_name    = $row["course_name"];
    $course_fees    = $row["course_fees"];
    $course_completion = $row["course_completion"];
    $applicant_name = $row["applicant_name"];
    $email_id = $row["email_id"];


}
 
// get institute name
$getInstName=$con->query("SELECT * FROM `institute_creation` JOIN initiate_application ON(institute_creation.institute_id=initiate_application.institute_like_to_appear) WHERE application_id ='".$application_id."' ");

while($row2=$getInstName->fetch_assoc()){
    $institute_id    = $row2["institute_id"];
    $institute_name   = $row2["institute_name"];
    $instalment_agree = $row2["instalment_agree"];
    $scholarship_avail = $row2["scholarship_avail"];
    $ins_email_id   = $row2["ins_email_id"];
   
}

// get institute name
$getInstrevName=$con->query("SELECT institute_review_id, batch_start_date, instalment_start_date, com_person1, com_person2, ins_person1 FROM institute_review WHERE ins_applicant_id ='".$application_id."' ");

while($row1=$getInstrevName->fetch_assoc()){
  
    
    $batch_start_date = $row1["batch_start_date"];
    $com_person1 = $row1["com_person1"];
    $com_person2 = $row1["com_person2"];
    $ins_person1 = $row1["ins_person1"];
   
}

// get instalment end date from committee review
$getcomrevName=$con->query("SELECT committee_review_id,end_date,start_date FROM committee_review WHERE applicant_id ='".$application_id."' ");

while($row3=$getcomrevName->fetch_assoc()){
  
    $instalment_end_date = $row3["end_date"];
    $instalment_start_date = $row3["start_date"];
      
}


$minimumrequirementName["institute_id"] = $institute_id;
$minimumrequirementName["institute_name"] = $institute_name;
$minimumrequirementName["instalment_agree"] = $instalment_agree;

$minimumrequirementName["course_name"] = $course_name;
$minimumrequirementName["course_fees"] = $course_fees;
$minimumrequirementName["course_completion"] = $course_completion;
$minimumrequirementName["applicant_name"] =$applicant_name;
$minimumrequirementName["email_id"] =$email_id;


$minimumrequirementName["instalment_start_date"] = $instalment_start_date;
$minimumrequirementName["batch_start_date"]	= $batch_start_date;
$minimumrequirementName["com_person1"] = $com_person1;
$minimumrequirementName["com_person2"] = $com_person2;
$minimumrequirementName["ins_person1"] = $ins_person1;
$minimumrequirementName["ins_email_id"] =$ins_email_id;

$minimumrequirementName["instalment_end_date"] = $instalment_end_date;
 
echo json_encode($minimumrequirementName);
?>
<?php
date_default_timezone_set('Asia/Calcutta');
@session_start();

$id=0;
$res = '';
include("api/main.php");
$msg="";
include("include/common/accounthead.php");

if(isset($_POST['submitSeeker_Register'])) 
{   
    if(isset($_POST["applicant_name"])){
        $applicant_name = $_POST["applicant_name"];	
    }
    if(isset($_POST["email_id"])){
        $email_id = $_POST["email_id"];	
    }
    if(isset($_POST["contact_no"])){
        $contact_no = $_POST["contact_no"];	
    }
    if(isset($_POST["address1"])){
        $address1 = $_POST["address1"];	
    }
    if(isset($_POST["address2"])){
        $address2 = $_POST["address2"];	
    }
    if(isset($_POST["address3"])){
        $address3 = $_POST["address3"];	
    }
    if(isset($_POST["place"])){
        $place = $_POST["place"];	
    }
    if(isset($_POST["pincode"])){
        $pincode = $_POST["pincode"];	
    }
    if(isset($_POST["user_name"])){
        $user_name = $_POST["user_name"];	
    }
    if(isset($_POST["password"])){
        $password = $_POST["password"];	
    }
    
    $message = array();
    
    $insertSeeker = "INSERT INTO seeker_registration(applicant_name, email_id, contact_number, address1, address2, address3, place, pincode, user_name, password) 
    VALUES('".strip_tags($applicant_name)."','".strip_tags($email_id)."', '".strip_tags($contact_no)."', '".strip_tags($address1)."', '".strip_tags($address2)."', 
    '".strip_tags($address3)."', '".strip_tags($place)."', '".strip_tags($pincode)."', '".strip_tags($user_name)."', '".strip_tags($password)."' )"; 
    $res = mysqli_query($mysqli, $insertSeeker); 

}


?>

<!-- Page header start -->
<!-- <div class="page-header">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">GSM - Registration of Seeker</li>
    </ol>

    <a href="editcustomer">
        <button type="button" class="btn btn-primary"><span class="icon-arrow-left"></span>&nbsp; Back</button>
    </a>
</div> -->
<!-- Page header end -->

<!-- Main container start -->
<div class="main-container">
	<!-- Row start -->
	<form action="" method="post" name="vendorcreation" id="vendorcreation" >
		<div class="row gutters">
		<!-- General Info -->
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
				<div class="card" style="box-shadow: none;">

                <!-- success message -->
                    <?php
                    if($res == true){ ?>
                    <div class="alert alert-success" role="alert">
                        <div class="alert-text" style="text-align: center; width: 100%;">Registered Successfully!</div>
                    </div>
                    <?php } ?>

                    
                    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                        <div class="card-header">GSM - Registration of Seeker</div>
                        <a href="editcustomer">
                            <button type="button" class="btn btn-primary"><span class="icon-arrow-left"></span>&nbsp; Back</button>
                        </a>
					</div>
                    
                    <input type="hidden" name="id" id="id" class="form-control" value="<?php if(isset($customer_id)) echo $customer_id; ?>">
					<div class="card-body row">
                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label class="label">Applicant Name<span style="color: red;">*</span></label>
                                <input type="text" tabindex="1" name="applicant_name" id="applicant_name" class="form-control" placeholder="Enter Applicant Name" value="<?php if(isset($applicant_name)) echo $applicant_name; ?>">
                                <span id="applicantnameCheck" class="text-danger" >Enter Applicant Name</span>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label for="inputReadOnly">E-Mail Id<span style="color: red;">*</span></label>
                                <input class="form-control" tabindex="6" id="email_id" name="email_id" type="text" value="<?php if(isset($email_id)) echo $email_id; ?>" placeholder="Enter Email Id">
                                <span class="text-danger" id="emailidCheck">Enter Valid E-mail Id</span>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label for="disabledInput">Contact Number<span style="color: red;">*</span></label>
                                <input type="number" id="contact_no" tabindex="5" name="contact_no" class="form-control"  value="<?php if(isset($contact_no)) echo $contact_no; ?>" placeholder="Enter Contact Number" onkeydown="javascript: return event.keyCode == 69 ? false : true" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;">
                                <span id="mobilenumbercheck" class="text-danger" >Enter Mobile Number</span>
                                <span id="mobilenumbercheck1" class="text-danger" >Mobile Number Already Exist</span>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label for="disabledInput">Address 1<span style="color: red;">*</span></label>
                                <input type="text" tabindex="2" id="address1" name="address1" class="form-control"  value="<?php if(isset($address1)) echo $address1; ?>" placeholder="Enter Address 1">
                                <span id="address1Check" class="text-danger" >Enter Address 1</span>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label for="disabledInput">Address 2</label>
                                <input type="text" tabindex="3" id="address2" name="address2" class="form-control"  value="<?php if(isset($address2)) echo $address2; ?>" placeholder="Enter Address 2">
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label for="disabledInput">Address 3</label>
                                <input type="text" tabindex="4" id="address3" name="address3" class="form-control"  value="<?php if(isset($address3)) echo $address3; ?>" placeholder="Enter Address 3">
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label for="inputReadOnly">Place<span style="color: red;">*</span></label>
                                <input type="text" class="form-control" tabindex="7" id="place" name="place" value="<?php if(isset($place)) echo $place; ?>" placeholder="Enter Place">
                                <span class="text-danger" id="placeCheck">Enter Place</span>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label class="label">Pincode<span style="color: red;">*</span></label>
                                <input type="number" tabindex="8" onkeydown="javascript: return event.keyCode == 69 ? false : true" name="pincode" id="pincode" class="form-control" placeholder="Enter Pincode" value="<?php if(isset($pincode )) echo $pincode ; ?>" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==6) return false;">
                                <span id="pincodeCheck" class="text-danger">Enter Pincode</span>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label for=""> User Name</label>
                                <input type="text" readonly class="form-control" id="user_name" name="user_name" placeholder="Enter User Name" value="<?php if($idupd > 0){ if(isset($user_name)) echo $user_name; } ?>" >
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="form-group">
                                <label for=""> Password</label>
                                <input type="password" readonly class="form-control" placeholder="Enter Password" id="password" name="password" value="<?php if($idupd > 0){  if(isset($user_password)) echo $user_password; } ?>" >
                            </div>
                        </div>

                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mt-4">
                            <div class="text-right">
                                <div>
                                    <button type="submit" tabindex="9" name="submitSeeker_Register" id="submitSeeker_Register" class="btn btn-primary">Submit</button>&nbsp;&nbsp;&nbsp;
                                    <button type="reset" tabindex="10" class="btn btn-outline-secondary">Cancel</button> 
                                </div> <br><br>
                            </div>
                        </div>
                    </div>
			    </div>

		</div>
	</form>
</div>
<?php include("include/common/dashboardfooter.php"); ?>
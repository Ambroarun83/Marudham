<?php
include '../ajaxconfig.php';

if (isset($_POST['course_category_id'])) {
    $course_category_id = $_POST['course_category_id'];
}
if (isset($_POST['course_category_name'])) {
    $course_category_name = $_POST['course_category_name'];
}

$crsNme='';
$crsStatus='';
$selectCategory=$con->query("SELECT * FROM course_category WHERE course_category_name = '".$course_category_name."' ");
while ($row=$selectCategory->fetch_assoc()){
	$crsNme    = $row["course_category_name"];
	$crsStatus  = $row["status"];
}

if($crsNme != '' && $crsStatus == 0){
	$message="Category Already Exists, Please Enter a Different Name!";
}
else if($crsNme != '' && $crsStatus == 1){
	$updateCategory=$con->query("UPDATE course_category SET status=0 WHERE course_category_name='".$course_category_name."' ");
	$message="Category Added Succesfully";
}
else{
	if($course_category_id>0){
		$updateCategory=$con->query("UPDATE course_category SET course_category_name='".$course_category_name."' WHERE course_category_id='".$course_category_id."' ");
		if($updateCategory == true){
		    $message="Category Updated Succesfully";
	    }
    }
	else{
	    $insertCategory=$con->query("INSERT INTO course_category(course_category_name) VALUES('".strip_tags($course_category_name)."')");
	    if($insertCategory == true){
		    $message="Category Added Succesfully";
	    }
    }
}

echo json_encode($message);
?>
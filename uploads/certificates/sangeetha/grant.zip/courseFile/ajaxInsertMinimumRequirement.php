<?php
include '../ajaxconfig.php';

if (isset($_POST['minimum_requirement_id'])) {
    $minimum_requirement_id = $_POST['minimum_requirement_id'];
}
if (isset($_POST['minimum_requirement_name'])) {
    $minimum_requirement_name = $_POST['minimum_requirement_name'];
}

$crsNme='';
$crsStatus='';

$selectCategory=$con->query("SELECT * FROM minimum_requirement WHERE minimum_requirement_name = '".$minimum_requirement_name."' ");
while ($row=$selectCategory->fetch_assoc()){
	$crsNme    = $row["minimum_requirement_name"];
	$crsStatus  = $row["status"];
}

if($crsNme != '' && $crsStatus == 0){
	$message="Minimum Requiremet Already Exists, Please Enter a Different Name!";
}
else if($crsNme != '' && $crsStatus == 1){
	$updateCategory=$con->query("UPDATE minimum_requirement SET status=0 WHERE minimum_requirement_name='".$minimum_requirement_name."' ");
	$message="Minimum Requiremet Added Succesfully";
}
else{
	if($minimum_requirement_id>0){
		$updateCategory=$con->query("UPDATE minimum_requirement SET minimum_requirement_name='".$minimum_requirement_name."' WHERE minimum_requirement_id='".$minimum_requirement_id."' ");
		if($updateCategory == true){
		    $message="Minimum Requiremet Updated Succesfully";
	    }
    }
	else{
	    $insertCategory=$con->query("INSERT INTO minimum_requirement(minimum_requirement_name) VALUES('".strip_tags($minimum_requirement_name)."')");
	    if($insertCategory == true){
		    $message="Minimum Requiremet Added Succesfully";
	    }
    }
}

echo json_encode($message);
?>
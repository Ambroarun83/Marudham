<?php
include '../ajaxconfig.php';

if(isset($_POST["course_category_id"])){
	$course_category_id  = $_POST["course_category_id"];
}

$getct = "SELECT * FROM course_category WHERE course_category_id = '".$course_category_id."' AND status=0";
$result = $con->query($getct);
while($row=$result->fetch_assoc())
{
    $course_category_name = $row['course_category_name'];
}

echo $course_category_name;
?>
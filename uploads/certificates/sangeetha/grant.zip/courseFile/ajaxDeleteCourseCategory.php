<?php
include '../ajaxconfig.php';

if(isset($_POST["course_category_id"])){
	$course_category_id  = $_POST["course_category_id"];
}
$isdel = '';

$ctqry=$con->query("SELECT * FROM course_creation WHERE course_category = '".$course_category_id."' ");
while($row=$ctqry->fetch_assoc()){
	$isdel=$row["course_category"];
}

if($isdel != ''){ 
	$message="You Don't Have Rights To Delete This Category";
}
else
{ 
	$delct=$con->query("UPDATE course_category SET status = 1 WHERE course_category_id = '".$course_category_id."' ");
	if($delct){
		$message="Category Inactivated Successfully";
	}
}

echo json_encode($message);
?>
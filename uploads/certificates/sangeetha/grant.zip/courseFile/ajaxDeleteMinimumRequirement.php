<?php
include '../ajaxconfig.php';

if(isset($_POST["minimum_requirement_id"])){
	$minimum_requirement_id  = $_POST["minimum_requirement_id"];
}
$isdel = '';

$ctqry=$con->query("SELECT * FROM course_creation WHERE minimum_requirement = '".$minimum_requirement_id."' ");
while($row=$ctqry->fetch_assoc()){
	$isdel=$row["minimum_requirement"];
}

if($isdel != ''){ 
	$message="You Don't Have Rights To Delete This Minimum Requiremet";
}
else
{ 
	$delct=$con->query("UPDATE minimum_requirement SET status = 1 WHERE minimum_requirement_id = '".$minimum_requirement_id."' ");
	if($delct){
		$message="Minimum Requiremet Inactivated Successfully";
	}
}

echo json_encode($message);
?>
<?php
include '../ajaxconfig.php';

if(isset($_POST["minimum_requirement_id"])){
	$minimum_requirement_id  = $_POST["minimum_requirement_id"];
}

$getct = "SELECT * FROM minimum_requirement WHERE minimum_requirement_id = '".$minimum_requirement_id."' AND status=0";
$result = $con->query($getct);
while($row=$result->fetch_assoc())
{
    $minimum_requirement_name = $row['minimum_requirement_name'];
}

echo $minimum_requirement_name;
?>
<?php
@session_start();
include('ajaxconfig.php');

if(isset($_SESSION["userid"])){
    $userid = $_SESSION["userid"];
}

$column = array(
    'investment_entry_id',
    'voucher_ref',
    'donor_name',
    'date_of_entry',
    'debit_ledger',
    'debit_amount',
    'credit_ledger',
    'credit_amount',
    'narration',
    'status'
);

$query = "SELECT * FROM investment_entry WHERE 1";

if($_POST['search']!="");
{
    if (isset($_POST['search'])) {

        if($_POST['search']=="Active")
        {
            $query .="and status=0 "; 
        }
        else if($_POST['search']=="Inactive")
        {
            $query .="and status=1 ";
        }

        else {	
            $query .= "
            and investment_entry_id LIKE  '%".$_POST['search']."%'
            or voucher_ref LIKE  '%".$_POST['search']."%'
            or donor_name LIKE  '%".$_POST['search']."%'
            OR date_of_entry LIKE '%".$_POST['search']."%'
            OR debit_ledger LIKE '%".$_POST['search']."%'
            OR debit_amount LIKE '%".$_POST['search']."%'
            OR credit_ledger LIKE '%".$_POST['search']."%'
            OR credit_amount LIKE '%".$_POST['search']."%'
            OR narration LIKE '%".$_POST['search']."%'
            OR status LIKE '%".$_POST['search']."%' ";
        }
    }
}

if (isset($_POST['order'])) {
    $query .= 'ORDER BY ' . $column[$_POST['order']['0']['column']] . ' ' . $_POST['order']['0']['dir'] . ' ';
} else {
    $query .= ' ';
}

$query1 = '';

if ($_POST['length'] != -1) {
    $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

$statement = $connect->prepare($query);
$statement->execute();
$number_filter_row = $statement->rowCount();
$statement = $connect->prepare($query . $query1);
$statement->execute();
$result = $statement->fetchAll();
$data = array();

$sno = 1;
foreach ($result as $row) {
    $sub_array   = array();
    
    if($sno!="")
    {
        $sub_array[] = $sno;
    }
	
    $sub_array[] = $row['voucher_ref'];
    $sub_array[] = $row['credit_ledger'];
    $sub_array[] = $row['date_of_entry'];
    $sub_array[] = $row['debit_ledger'];
    $sub_array[] = $row['debit_amount'];
    $sub_array[] = $row['credit_ledger'];
    $sub_array[] = $row['credit_amount'];
    $sub_array[] = $row['narration'];
    $status      = $row['status'];

    if($status == 1)
	{
	$sub_array[] = "<span style='width: 144px;'><span class='kt-badge  kt-badge--danger kt-badge--inline kt-badge--pill'>Inactive</span></span>";
	}
	else
	{
    $sub_array[] = "<span style='width: 144px;'><span class='kt-badge  kt-badge--success kt-badge--inline kt-badge--pill'>Active</span></span>";
	}
	$id          = $row['investment_entry_id'];
	
	$action="<a href='investment_entry&upd=$id' title='Edit details'><span class='icon-border_color'></span></a>&nbsp;&nbsp; 
	<a href='investment_entry&del=$id' title='Delete details' class='delete_investment'><span class='icon-trash-2'></span></a>";

	$sub_array[] = $action;
    $data[]      = $sub_array;
    $sno         = $sno + 1;
} 

function count_all_data($connect)
{
    $query     = "SELECT * FROM investment_entry where status = '0' ";
    $statement = $connect->prepare($query);
    $statement->execute();
    return $statement->rowCount();
}

$output = array(
    'draw' => intval($_POST['draw']),
    'recordsTotal' => count_all_data($connect),
    'recordsFiltered' => $number_filter_row,
    'data' => $data
);

echo json_encode($output);
?>
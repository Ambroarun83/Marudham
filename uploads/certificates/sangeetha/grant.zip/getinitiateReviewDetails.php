<?php
@session_start();
include 'ajaxconfig.php';

if(isset($_SESSION["userid"])){
    $userid = $_SESSION["userid"];
}
if(isset($_POST["application_id"])){
	$application_id = $_POST["application_id"];
}

 
$course_name = '';
$course_fees = '';
$course_completion = '';
$committee_review_id ='';
$person1 = '';
$person2 = '';
$start_date = '';


// get course details
$getMinReq=$con->query("SELECT * FROM `initiate_application` join course_creation on (course_creation.course_id=initiate_application.course_required_to_appear) WHERE application_id = '".$application_id."' ");
while($row=$getMinReq->fetch_assoc()){
    $course_name    = $row["course_name"];
    $course_fees    = $row["course_fees"];
    $course_completion = $row["course_completion"];
   
    
}
//get Committee Review

 $getcomName=$con->query("SELECT person1, person2, start_date, committee_review_id FROM committee_review WHERE applicant_id = '".$application_id."' ");
    while($row1=$getcomName->fetch_assoc()){
        $committee_review_id    = $row1["committee_review_id"];
        $person1    = $row1["person1"];
        $person2    = $row1["person2"];
        $start_date = $row1["start_date"];
    }


$minimumrequirementName["course_name"] = $course_name;
$minimumrequirementName["course_fees"] = $course_fees;
$minimumrequirementName["course_completion"] = $course_completion;


$minimumrequirementName["person1"] = $person1;
$minimumrequirementName["person2"] = $person2;
$minimumrequirementName["start_date"] = $start_date;
 
echo json_encode($minimumrequirementName);
?>
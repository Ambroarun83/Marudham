<?php
include('ajaxconfig.php');

if(isset($_POST["applicant_name"])){
    $applicant_name = $_POST["applicant_name"];	
}
if(isset($_POST["email_id"])){
    $email_id = $_POST["email_id"];	
}
if(isset($_POST["contact_no"])){
    $contact_no = $_POST["contact_no"];	
}
if(isset($_POST["address1"])){
    $address1 = $_POST["address1"];	
}
if(isset($_POST["address2"])){
    $address2 = $_POST["address2"];	
}
if(isset($_POST["address3"])){
    $address3 = $_POST["address3"];	
}
if(isset($_POST["place"])){
    $place = $_POST["place"];	
}
if(isset($_POST["pincode"])){
    $pincode = $_POST["pincode"];	
}
if(isset($_POST["user_name"])){
    $user_name = $_POST["user_name"];	
}
if(isset($_POST["password"])){
    $password = $_POST["password"];	
}

$message = array();

$insertSeeker = $con->query("INSERT INTO seeker_registration(applicant_name, email_id, contact_no, address1, address2, address3, place, pincode, user_name, password) 
VALUES('".strip_tags($applicant_name)."','".strip_tags($email_id)."', '".strip_tags($contact_no)."', '".strip_tags($address1)."', '".strip_tags($address2)."', 
'".strip_tags($address3)."', '".strip_tags($place)."', '".strip_tags($pincode)."', '".strip_tags($user_name)."', '".strip_tags($password)."' )");

if(!empty($insertSeeker)){
	$message['status'] = 0;
}else{
	$message['status'] = 1;
}

echo json_encode($message);
?>
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2022 at 08:15 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grant`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountsgroup`
--

CREATE TABLE `accountsgroup` (
  `Id` int(11) NOT NULL,
  `AccountsName` longtext DEFAULT NULL,
  `ParentId` int(11) DEFAULT 0,
  `status` int(11) DEFAULT 0,
  `order_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accountsgroup`
--

INSERT INTO `accountsgroup` (`Id`, `AccountsName`, `ParentId`, `status`, `order_id`) VALUES
(1, 'Capital Account', 0, 0, 1),
(2, 'Current Liabilities', 0, 0, 2),
(3, 'Current Assets', 0, 0, 4),
(4, 'Purchase Accounts', 0, 0, 5),
(5, 'Direct Income', 0, 0, 6),
(6, 'Direct Expenses', 0, 0, 7),
(7, 'Indirect Income', 0, 0, 8),
(8, 'Indirect Expenses', 0, 0, 9),
(9, 'Profit & Loss A/c', 0, 0, 10),
(10, 'Diff. in Opening Balances', 0, 0, 11),
(11, 'Reserve & Surplus', 1, 0, 12),
(12, 'Sundry Creditors', 2, 0, 13),
(13, 'Loans(Liability)', 2, 0, 14),
(14, 'Bank OD', 2, 0, 15),
(15, 'Opening Stock', 3, 0, 16),
(16, 'Cash-in-hand', 3, 0, 17),
(17, 'Bank Accounts', 3, 0, 18),
(18, 'Investments', 3, 0, 19),
(19, 'Loans and Advances', 3, 0, 20),
(40, 'Sundry Debtors', 3, 0, 35),
(42, 'Fixed Assets', 0, 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `bankmaster`
--

CREATE TABLE `bankmaster` (
  `bankid` int(11) NOT NULL,
  `bankcode` varchar(255) DEFAULT NULL,
  `bankname` varchar(255) DEFAULT NULL,
  `accountno` varchar(255) DEFAULT NULL,
  `branchname` varchar(255) DEFAULT NULL,
  `shortform` varchar(255) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  `mailid` varchar(255) DEFAULT NULL,
  `ifsccode` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `contactno` varchar(255) DEFAULT NULL,
  `micrcode` varchar(255) DEFAULT NULL,
  `typeofaccount` varchar(255) DEFAULT NULL,
  `undersubgroup` varchar(255) DEFAULT NULL,
  `fgroup` varchar(255) DEFAULT NULL,
  `bankgrouprefid` varchar(20) DEFAULT NULL,
  `ledgername` varchar(255) DEFAULT NULL,
  `costcenter` varchar(255) DEFAULT NULL,
  `fromperiod` varchar(50) DEFAULT NULL,
  `toperiod` varchar(50) DEFAULT NULL,
  `duedate` varchar(50) DEFAULT NULL,
  `loanamount` int(11) DEFAULT NULL,
  `emi` int(11) DEFAULT NULL,
  `restofinterest` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `insert_login_id` int(11) DEFAULT NULL,
  `update_login_id` int(11) DEFAULT NULL,
  `delete_login_id` int(11) DEFAULT NULL,
  `createddate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bankmaster`
--

INSERT INTO `bankmaster` (`bankid`, `bankcode`, `bankname`, `accountno`, `branchname`, `shortform`, `purpose`, `mailid`, `ifsccode`, `contactperson`, `contactno`, `micrcode`, `typeofaccount`, `undersubgroup`, `fgroup`, `bankgrouprefid`, `ledgername`, `costcenter`, `fromperiod`, `toperiod`, `duedate`, `loanamount`, `emi`, `restofinterest`, `status`, `insert_login_id`, `update_login_id`, `delete_login_id`, `createddate`) VALUES
(1, 'BANK1001', 'SBI', '23423434234', 'Tiruvannamalai', 'TVM', '1', '', '', '', '', '234234234', 'normalaccounts', '17', '3', '3', 'SBI', '0', '', '', '', 0, 0, 0, 0, 1, 1, 1, '2022-11-17 09:33:55');

-- --------------------------------------------------------

--
-- Table structure for table `candidate_details`
--

CREATE TABLE `candidate_details` (
  `candidate_details_id` int(11) NOT NULL,
  `insert_userid` int(11) DEFAULT NULL,
  `update_userid` int(11) DEFAULT NULL,
  `delete_userid` int(11) DEFAULT NULL,
  `applicant_id` varchar(250) DEFAULT NULL,
  `instalment_details` varchar(250) DEFAULT NULL,
  `institute_details` varchar(250) DEFAULT NULL,
  `course_fees` varchar(250) DEFAULT NULL,
  `joining_date` varchar(250) DEFAULT NULL,
  `batch_start_date` varchar(250) DEFAULT NULL,
  `instalment_start_date` varchar(250) DEFAULT NULL,
  `spoc` varchar(250) DEFAULT NULL,
  `contact_details` varchar(250) DEFAULT NULL,
  `voucher_ref` varchar(250) DEFAULT NULL,
  `paid_date` varchar(250) DEFAULT NULL,
  `amount` int(250) DEFAULT NULL,
  `review1` varchar(250) DEFAULT NULL,
  `review2` varchar(250) DEFAULT NULL,
  `review3` varchar(250) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidate_details`
--

INSERT INTO `candidate_details` (`candidate_details_id`, `insert_userid`, `update_userid`, `delete_userid`, `applicant_id`, `instalment_details`, `institute_details`, `course_fees`, `joining_date`, `batch_start_date`, `instalment_start_date`, `spoc`, `contact_details`, `voucher_ref`, `paid_date`, `amount`, `review1`, `review2`, `review3`, `status`, `created_date`, `updated_date`) VALUES
(1, 1, NULL, NULL, '-siva', 'sdsdfsd', 'dfsdf', '1000', '2022-11-16', '2022-11-16', '2022-11-16', 'fgdsfgdf', 'dfgsdfg', '', '2022-11-16', 10000, 'fgdfgdsf', 'dfgsdfgsd', 'dfgdsfgdsf', 0, '2022-11-15 12:59:29', '2022-11-15 12:59:29'),
(2, 1, 1, NULL, '-sivabala23', 'sdsdfsd', 'dfsdf', '1000', '2022-11-16', '2022-11-16', '2022-11-16', 'fgdsfgdf', 'dfgsdfg', 'dsfgdsfg', '2022-11-16', 10000, 'dsfdsadf', 'fsdfsadf', 'sdfasdfsadf', 0, '2022-11-15 13:00:21', '2022-11-15 13:00:21'),
(1, 1, NULL, NULL, '-siva', 'sdsdfsd', 'dfsdf', '1000', '2022-11-16', '2022-11-16', '2022-11-16', 'fgdsfgdf', 'dfgsdfg', '', '2022-11-16', 10000, 'fgdfgdsf', 'dfgsdfgsd', 'dfgdsfgdsf', 0, '2022-11-15 12:59:29', '2022-11-15 12:59:29'),
(2, 1, 1, NULL, '-sivabala23', 'sdsdfsd', 'dfsdf', '1000', '2022-11-16', '2022-11-16', '2022-11-16', 'fgdsfgdf', 'dfgsdfg', 'dsfgdsfg', '2022-11-16', 10000, 'dsfdsadf', 'fsdfsadf', 'sdfasdfsadf', 0, '2022-11-15 13:00:21', '2022-11-15 13:00:21');

-- --------------------------------------------------------

--
-- Table structure for table `committee_creation`
--

CREATE TABLE `committee_creation` (
  `committee_id` int(11) NOT NULL,
  `committee_name` varchar(255) DEFAULT NULL,
  `assign_staff` varchar(255) DEFAULT NULL,
  `committee_purpose` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `insert_login_id` int(11) DEFAULT NULL,
  `update_login_id` int(11) DEFAULT NULL,
  `delete_login_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `committee_creation`
--

INSERT INTO `committee_creation` (`committee_id`, `committee_name`, `assign_staff`, `committee_purpose`, `status`, `insert_login_id`, `update_login_id`, `delete_login_id`, `created_date`, `updated_date`) VALUES
(1, 'test committee', 'Barath', 'test', 0, 1, NULL, NULL, '2022-11-17 16:25:08', '2022-11-17 16:25:08');

-- --------------------------------------------------------

--
-- Table structure for table `committee_review`
--

CREATE TABLE `committee_review` (
  `committee_review_id` int(11) NOT NULL,
  `applicant_id` varchar(250) DEFAULT NULL,
  `course_required` varchar(255) DEFAULT NULL,
  `institute_likely_to_appear` varchar(255) DEFAULT NULL,
  `course_fees` varchar(255) DEFAULT NULL,
  `review_date` varchar(255) DEFAULT NULL,
  `course_completion` varchar(255) DEFAULT NULL,
  `certification_view` varchar(255) DEFAULT NULL,
  `instalment_detils` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `person1` text NOT NULL,
  `person2` text NOT NULL,
  `final_recommodation` varchar(255) DEFAULT NULL,
  `comment` varchar(250) DEFAULT NULL,
  `is_applicant` int(11) DEFAULT NULL,
  `email_id` varchar(250) DEFAULT NULL,
  `institute_review` int(11) NOT NULL DEFAULT 0,
  `insert_userid` int(11) DEFAULT NULL,
  `update_userid` int(11) DEFAULT NULL,
  `delete_userid` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `committee_review`
--

INSERT INTO `committee_review` (`committee_review_id`, `applicant_id`, `course_required`, `institute_likely_to_appear`, `course_fees`, `review_date`, `course_completion`, `certification_view`, `instalment_detils`, `start_date`, `end_date`, `person1`, `person2`, `final_recommodation`, `comment`, `is_applicant`, `email_id`, `institute_review`, `insert_userid`, `update_userid`, `delete_userid`, `status`, `created_date`, `updated_date`) VALUES
(1, '3', 'BCA', '1', '50000', '', 'B.Sc', NULL, '2', '2022-11-24', '2023-01-24', 'dfsdfsad', 'sdfsdf', 'Pass', '', 0, 'sivashankari2903@gmail.com', 0, 1, NULL, NULL, 0, '2022-11-22 12:22:32', '2022-11-22 12:22:32'),
(2, '2', 'BCA', '1', '50000', '', 'B.Sc', NULL, '2', '2022-11-25', '2023-01-25', 'tert', 'ertert', 'Pass', '', 0, 'sivashankari2903@gmail.com', 0, 1, NULL, NULL, 0, '2022-11-22 12:32:03', '2022-11-22 12:32:03'),
(3, '4', 'BCA', '2', '50000', '', 'M.sc', NULL, '3', '2022-11-18', '2023-02-18', '', '', 'Pass', '', 0, 'tjagan1995@gmail.com', 0, 1, NULL, NULL, 0, '2022-11-22 12:33:19', '2022-11-22 12:33:19'),
(4, '1', 'BCA', '2', '50000', '', 'B.Sc', NULL, '3', '2022-11-25', '2023-02-25', '', '', 'Pass', '', 0, 'sivashankari2903@gmail.com', 0, 1, NULL, NULL, 0, '2022-11-22 12:36:55', '2022-11-22 12:36:55'),
(5, '3', 'BCA', '1', '50000', '', 'B.Sc', NULL, '2', '2022-11-26', '2023-01-26', '', '', 'Pass', '', 0, 'sivashankari2903@gmail.com', 0, 1, NULL, NULL, 0, '2022-11-22 12:39:24', '2022-11-22 12:39:24'),
(6, '4', 'BCA', '2', '50000', '', 'M.sc', NULL, '3', '', '', '', '', 'Pass', '', 0, 'tjagan1995@gmail.com', 0, 1, NULL, NULL, 0, '2022-11-22 12:44:18', '2022-11-22 12:44:18');

-- --------------------------------------------------------

--
-- Table structure for table `confirmation`
--

CREATE TABLE `confirmation` (
  `confirmation_id` int(11) NOT NULL,
  `applicant_name1` varchar(255) DEFAULT NULL,
  `course_required` varchar(255) DEFAULT NULL,
  `course_fees` varchar(255) DEFAULT NULL,
  `instalment_details` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `com_applicant_id` int(11) NOT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `confirmation_date` varchar(255) DEFAULT NULL,
  `course_completion` varchar(255) DEFAULT NULL,
  `certification_view` varchar(255) DEFAULT NULL,
  `batch_start_date` varchar(255) DEFAULT NULL,
  `instalment_start_date` varchar(255) DEFAULT NULL,
  `com_person1` text DEFAULT NULL,
  `com_person2` text DEFAULT NULL,
  `ins_person1` text DEFAULT NULL,
  `scholarship` varchar(255) DEFAULT NULL,
  `institute_name` varchar(250) DEFAULT NULL,
  `insert_userid` int(11) DEFAULT NULL,
  `update_userid` int(11) DEFAULT NULL,
  `delete_userid` int(11) DEFAULT NULL,
  `instalment_start_date1` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `status1` int(11) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp(),
  `app_email_id` varchar(255) DEFAULT NULL,
  `ins_email_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `confirmation`
--

INSERT INTO `confirmation` (`confirmation_id`, `applicant_name1`, `course_required`, `course_fees`, `instalment_details`, `start_date`, `com_applicant_id`, `end_date`, `confirmation_date`, `course_completion`, `certification_view`, `batch_start_date`, `instalment_start_date`, `com_person1`, `com_person2`, `ins_person1`, `scholarship`, `institute_name`, `insert_userid`, `update_userid`, `delete_userid`, `instalment_start_date1`, `status`, `status1`, `created_date`, `updated_date`, `app_email_id`, `ins_email_id`) VALUES
(1, 'Mani', 'BCA', '50000', '2', '2022-11-24', 3, '2023-01-24', '2022-11-24', 'B.Sc', NULL, '2022-11-17', NULL, 'dfsdfsad', 'sdfsdf', 'dfsdfsd', 'Yes', NULL, 1, NULL, NULL, NULL, 0, 0, '2022-11-22 12:22:58', '2022-11-22 12:22:58', 'sivashankari2903@gmail.com', 'sivashankari2903@gmail.com'),
(2, 'Mani', 'BCA', '50000', '2', '2022-11-24', 3, '2023-01-24', '2022-11-24', 'B.Sc', NULL, '2022-11-17', NULL, 'dfsdfsad', 'sdfsdf', 'dfsdfsd', 'Yes', NULL, 1, NULL, NULL, NULL, 0, 0, '2022-11-22 12:31:32', '2022-11-22 12:31:32', 'sivashankari2903@gmail.com', 'sivashankari2903@gmail.com'),
(3, 'Suriya', 'BCA', '50000', '2', '2022-11-25', 2, '2023-01-25', '2022-11-23', 'B.Sc', NULL, '2022-11-17', NULL, 'tert', 'ertert', 'rtertert', 'Yes', NULL, 1, NULL, NULL, NULL, 0, 0, '2022-11-22 12:32:29', '2022-11-22 12:32:29', 'sivashankari2903@gmail.com', 'sivashankari2903@gmail.com'),
(4, 'Jagan', 'BCA', '50000', '3', '2022-11-18', 4, '2023-02-18', '', 'M.sc', NULL, '2022-11-16', NULL, '', '', 'sdfsdf', 'Yes', NULL, 1, NULL, NULL, NULL, 0, 0, '2022-11-22 12:33:53', '2022-11-22 12:33:53', 'tjagan1995@gmail.com', 'sivashankari2903@gmail.com'),
(5, 'Jagan', 'BCA', '50000', '3', '2022-11-18', 4, '2023-02-18', '', 'M.sc', NULL, '2022-11-16', NULL, '', '', 'sdfsdf', 'Yes', NULL, 1, NULL, NULL, NULL, 0, 0, '2022-11-22 12:36:00', '2022-11-22 12:36:00', 'tjagan1995@gmail.com', 'sivashankari2903@gmail.com'),
(6, 'Jagan', 'BCA', '50000', '3', '2022-11-18', 4, '2023-02-18', '', 'M.sc', NULL, '2022-11-16', NULL, '', '', 'sdfsdf', 'Yes', NULL, 1, NULL, NULL, NULL, 0, 0, '2022-11-22 12:36:30', '2022-11-22 12:36:30', 'tjagan1995@gmail.com', 'sivashankari2903@gmail.com'),
(7, 'Suriya', 'BCA', '50000', '3', '2022-11-25', 1, '2023-02-25', '', 'B.Sc', NULL, '2022-11-18', NULL, '', '', 'vdfgdfg', 'Yes', NULL, 1, NULL, NULL, NULL, 0, 0, '2022-11-22 12:37:17', '2022-11-22 12:37:17', 'sivashankari2903@gmail.com', 'sivashankari2903@gmail.com'),
(8, 'Mani', 'BCA', '50000', '2', '2022-11-26', 3, '2023-01-26', '', 'B.Sc', NULL, '2022-11-23', NULL, '', '', 'dsdfsdf', 'Yes', NULL, 1, NULL, NULL, NULL, 0, 0, '2022-11-22 12:39:46', '2022-11-22 12:39:46', 'sivashankari2903@gmail.com', 'sivashankari2903@gmail.com'),
(9, 'Mani', 'BCA', '50000', '2', '2022-11-26', 3, '2023-01-26', '', 'B.Sc', NULL, '2022-11-23', NULL, '', '', 'dsdfsdf', 'Yes', NULL, 1, NULL, NULL, NULL, 0, 0, '2022-11-22 12:43:25', '2022-11-22 12:43:25', 'sivashankari2903@gmail.com', 'sivashankari2903@gmail.com'),
(10, 'Mani', 'BCA', '50000', '2', '2022-11-26', 3, '2023-01-26', '', 'B.Sc', NULL, '2022-11-23', NULL, '', '', 'dsdfsdf', 'Yes', NULL, 1, NULL, NULL, NULL, 0, 0, '2022-11-22 12:43:36', '2022-11-22 12:43:36', 'sivashankari2903@gmail.com', 'sivashankari2903@gmail.com'),
(11, 'Jagan', 'BCA', '50000', '3', '', 4, '', '', 'M.sc', NULL, '2022-11-18', NULL, '', '', 'dfsdfsd', 'Yes', NULL, 1, NULL, NULL, NULL, 0, 0, '2022-11-22 12:44:47', '2022-11-22 12:44:47', 'tjagan1995@gmail.com', 'sivashankari2903@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `costcentre`
--

CREATE TABLE `costcentre` (
  `costcentreid` int(11) NOT NULL,
  `costcentrename` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `costcentre`
--

INSERT INTO `costcentre` (`costcentreid`, `costcentrename`, `status`) VALUES
(1, 'Celebration Charges', '0'),
(2, 'Faculty Bus', '0'),
(3, 'Sale', '0'),
(4, 'Purchase', '0'),
(5, 'Salary', '0'),
(6, 'Admin', '0'),
(7, 'test', '0');

-- --------------------------------------------------------

--
-- Table structure for table `course_category`
--

CREATE TABLE `course_category` (
  `course_category_id` int(11) NOT NULL,
  `course_category_name` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course_category`
--

INSERT INTO `course_category` (`course_category_id`, `course_category_name`, `status`, `created_date`, `updated_date`) VALUES
(1, 'Arts and Science', 0, '2022-11-17 10:53:02', '2022-11-17 10:53:02'),
(2, 'Engineering', 0, '2022-11-17 11:06:26', '2022-11-17 11:06:26');

-- --------------------------------------------------------

--
-- Table structure for table `course_completion`
--

CREATE TABLE `course_completion` (
  `course_completion_id` int(11) NOT NULL,
  `applicant_name` varchar(250) DEFAULT NULL,
  `course_name` varchar(250) DEFAULT NULL,
  `course_fees` varchar(250) DEFAULT NULL,
  `amount_paid` varchar(250) DEFAULT NULL,
  `certificate` varchar(250) DEFAULT NULL,
  `insert_userid` int(11) NOT NULL,
  `update_userid` int(11) NOT NULL,
  `delete_userid` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `rating` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course_completion`
--

INSERT INTO `course_completion` (`course_completion_id`, `applicant_name`, `course_name`, `course_fees`, `amount_paid`, `certificate`, `insert_userid`, `update_userid`, `delete_userid`, `status`, `created_date`, `updated_date`, `rating`) VALUES
(1, '', 'TestBatch2', '1000', '500', '', 1, 0, 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '5'),
(2, '-sivabala23', 'TestBatch2', '1000', '500', '', 1, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '5'),
(1, '', 'TestBatch2', '1000', '500', '', 1, 0, 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '5'),
(2, '-sivabala23', 'TestBatch2', '1000', '500', '', 1, 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '5');

-- --------------------------------------------------------

--
-- Table structure for table `course_creation`
--

CREATE TABLE `course_creation` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) DEFAULT NULL,
  `course_category` varchar(255) DEFAULT NULL,
  `course_duration` varchar(255) DEFAULT NULL,
  `course_fees` int(11) NOT NULL,
  `minimum_requirement` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `insert_login_id` int(11) DEFAULT NULL,
  `update_login_id` int(11) DEFAULT NULL,
  `delete_login_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course_creation`
--

INSERT INTO `course_creation` (`course_id`, `course_name`, `course_category`, `course_duration`, `course_fees`, `minimum_requirement`, `status`, `insert_login_id`, `update_login_id`, `delete_login_id`, `created_date`, `updated_date`) VALUES
(1, 'BCA', '1', '3 Years', 50000, '1', 0, 1, NULL, NULL, '2022-11-17 11:08:12', '2022-11-17 11:08:12'),
(2, 'Maths', '2', '1year', 2000, '1', 0, 1, NULL, NULL, '2022-11-21 12:16:42', '2022-11-21 12:16:42'),
(3, 'Science', '2', '3 Years', 1000, '1', 0, 1, NULL, NULL, '2022-11-21 13:33:18', '2022-11-21 13:33:18');

-- --------------------------------------------------------

--
-- Table structure for table `department_creation`
--

CREATE TABLE `department_creation` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department_creation`
--

INSERT INTO `department_creation` (`department_id`, `department_name`, `status`, `created_date`, `updated_date`) VALUES
(1, 'HR', 0, '2022-11-17 16:23:40', '2022-11-17 16:23:40'),
(2, 'TL', 0, '2022-11-17 16:23:47', '2022-11-17 16:23:47'),
(3, 'Employee', 0, '2022-11-17 16:23:53', '2022-11-17 16:23:53');

-- --------------------------------------------------------

--
-- Table structure for table `donator_creation`
--

CREATE TABLE `donator_creation` (
  `donator_id` int(11) NOT NULL,
  `donor_name` varchar(255) DEFAULT NULL,
  `address1` text DEFAULT NULL,
  `address2` text DEFAULT NULL,
  `address3` text DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `pan_number` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `insert_login_id` int(11) DEFAULT NULL,
  `update_login_id` int(11) DEFAULT NULL,
  `delete_login_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `donator_creation`
--

INSERT INTO `donator_creation` (`donator_id`, `donor_name`, `address1`, `address2`, `address3`, `place`, `pincode`, `pan_number`, `contact_number`, `email_id`, `status`, `insert_login_id`, `update_login_id`, `delete_login_id`, `created_date`, `updated_date`) VALUES
(6, 'Prem', 'Car Street', '', '', 'Chennai', '677767', 'wresdfsd43434', '2222222222', '', 0, 1, 1, 1, '2022-11-17 13:02:05', '2022-11-17 13:02:05'),
(7, 'Mukesh', 'Car Street', '', '', 'Chennai', '324234', 'ewr3dffefw', '3333333333', '', 0, 1, NULL, NULL, '2022-11-17 16:25:29', '2022-11-17 16:25:29');

-- --------------------------------------------------------

--
-- Table structure for table `initiate_application`
--

CREATE TABLE `initiate_application` (
  `application_id` int(11) NOT NULL,
  `application_number` varchar(250) DEFAULT NULL,
  `applicant_name` varchar(255) DEFAULT NULL,
  `address1` text DEFAULT NULL,
  `address2` text DEFAULT NULL,
  `address3` text DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `course_required_to_appear` varchar(255) DEFAULT NULL,
  `institute_like_to_appear` varchar(255) DEFAULT NULL,
  `course_fees` varchar(255) DEFAULT NULL,
  `course_duration` varchar(255) DEFAULT NULL,
  `scholarship_avail` varchar(255) DEFAULT NULL,
  `partial_amount` int(250) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `father_occupation` varchar(255) DEFAULT NULL,
  `father_income` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `course_completion` varchar(255) DEFAULT NULL,
  `certificate` varchar(255) DEFAULT NULL,
  `initiate_image` varchar(250) DEFAULT NULL,
  `minimum_requirement` varchar(250) DEFAULT NULL,
  `committee_review` int(11) NOT NULL DEFAULT 0,
  `institute_review1` int(11) NOT NULL DEFAULT 0,
  `confirmation1` int(11) NOT NULL DEFAULT 0,
  `insert_userid` int(11) DEFAULT NULL,
  `update_userid` int(11) DEFAULT NULL,
  `delete_userid` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `initiate_application`
--

INSERT INTO `initiate_application` (`application_id`, `application_number`, `applicant_name`, `address1`, `address2`, `address3`, `place`, `pincode`, `contact_number`, `email_id`, `course_required_to_appear`, `institute_like_to_appear`, `course_fees`, `course_duration`, `scholarship_avail`, `partial_amount`, `father_name`, `father_occupation`, `father_income`, `mother_name`, `course_completion`, `certificate`, `initiate_image`, `minimum_requirement`, `committee_review`, `institute_review1`, `confirmation1`, `insert_userid`, `update_userid`, `delete_userid`, `status`, `created_date`, `updated_date`) VALUES
(1, 'IANO-1/Nov22', 'Suriya', 'Address 1', '', '', 'pondy', '232323', '3434343434', 'sivashankari2903@gmail.com', '1', '2', '50000', '3 Years', 'Full', 0, '', '', '', '', 'B.Sc', 'check.png', '', '1', 0, 0, 0, 1, NULL, NULL, 0, '2022-11-22 10:37:30', '2022-11-22 10:37:30'),
(2, 'IANO-2/Nov22', 'Suriya', 'Address 1', '', '', 'pondy', '343434', '3454545534', 'sivashankari2903@gmail.com', '1', '1', '50000', '3 Years', 'Full', 0, '', '', '', '', 'B.Sc', 'wrong.png', '', '1', 0, 0, 0, 1, NULL, NULL, 0, '2022-11-22 10:47:20', '2022-11-22 10:47:20'),
(3, 'IANO-3/Nov22', 'Mani', 'Address 1', '', '', 'pondy', '656575', '6786786786', 'sivashankari2903@gmail.com', '1', '1', '50000', '3 Years', 'Full', 0, '', '', '', '', 'B.Sc', 'wrong.png', '', '1', 1, 1, 1, 1, NULL, NULL, 0, '2022-11-22 10:54:48', '2022-11-22 10:54:48'),
(4, 'IANO-4/Nov22', 'Jagan', 'Address 1', 'Address 2', '', 'pondy', '605454', '9895656532', 'tjagan1995@gmail.com', '1', '2', '50000', '3 Years', 'Full', 0, '', '', '', '', 'M.sc', 'check.png', '', '1', 1, 1, 1, 1, NULL, NULL, 0, '2022-11-22 11:33:30', '2022-11-22 11:33:30');

-- --------------------------------------------------------

--
-- Table structure for table `institute_creation`
--

CREATE TABLE `institute_creation` (
  `institute_id` int(11) NOT NULL,
  `institute_name` varchar(255) DEFAULT NULL,
  `course_offered` varchar(255) DEFAULT NULL,
  `address1` text DEFAULT NULL,
  `address2` text DEFAULT NULL,
  `address3` text DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `spoc` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `ins_email_id` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `instalment_agree` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `ifsc_code` varchar(255) DEFAULT NULL,
  `account_holder_name` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `insert_login_id` int(11) DEFAULT NULL,
  `update_login_id` int(11) DEFAULT NULL,
  `delete_login_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `institute_creation`
--

INSERT INTO `institute_creation` (`institute_id`, `institute_name`, `course_offered`, `address1`, `address2`, `address3`, `place`, `pincode`, `spoc`, `contact_number`, `ins_email_id`, `website`, `instalment_agree`, `account_number`, `bank_name`, `ifsc_code`, `account_holder_name`, `status`, `insert_login_id`, `update_login_id`, `delete_login_id`, `created_date`, `updated_date`) VALUES
(1, 'test', '1', 'Car Street', '', '', 'test', '234234', 'test', '2342342342', 'sivashankari2903@gmail.com', '', '2', '234234', 'test', 'etsfsdf33', 'test', 0, 1, NULL, NULL, '2022-11-17 12:34:38', '2022-11-17 12:34:38'),
(2, 'Mother Coaching Center', '1', 'Address 1', '', '', 'pondy', '605004', 'dfsdf', '6568956565', 'sivashankari2903@gmail.com', 'www.abd.in', '3', '986562325656', 'statebank', 'dfsdfsdfds', 'siva', 0, 1, NULL, NULL, '2022-11-21 12:17:28', '2022-11-21 12:17:28'),
(3, 'Vcc Coaching Center', '1,2', 'Address 1', '', '', 'pondy', '605004', 'dfsdf', '9865656454', 'mailid1@gmail.com', 'www.abd.in', '4', '878454215656', 'Indianbank', 'dfsdfsdfds', 'siva', 0, 1, NULL, NULL, '2022-11-21 12:18:13', '2022-11-21 12:18:13');

-- --------------------------------------------------------

--
-- Table structure for table `institute_review`
--

CREATE TABLE `institute_review` (
  `institute_review_id` int(11) NOT NULL,
  `ins_applicant_id` varchar(255) DEFAULT NULL,
  `insert_userid` int(11) DEFAULT NULL,
  `update_userid` int(11) DEFAULT NULL,
  `delete_userid` int(11) DEFAULT NULL,
  `course_required` varchar(255) DEFAULT NULL,
  `course_fees` varchar(255) DEFAULT NULL,
  `review_date` varchar(255) DEFAULT NULL,
  `course_completion` varchar(255) DEFAULT NULL,
  `certification_view` varchar(255) DEFAULT NULL,
  `com_person1` text DEFAULT NULL,
  `com_person2` text DEFAULT NULL,
  `ins_person1` text DEFAULT NULL,
  `batch_start_date` varchar(255) DEFAULT NULL,
  `instalment_start_date` varchar(255) DEFAULT NULL,
  `confirmation` int(11) NOT NULL DEFAULT 0,
  `status1` int(11) NOT NULL DEFAULT 0,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `institute_review`
--

INSERT INTO `institute_review` (`institute_review_id`, `ins_applicant_id`, `insert_userid`, `update_userid`, `delete_userid`, `course_required`, `course_fees`, `review_date`, `course_completion`, `certification_view`, `com_person1`, `com_person2`, `ins_person1`, `batch_start_date`, `instalment_start_date`, `confirmation`, `status1`, `status`, `created_date`, `updated_date`) VALUES
(1, '3', 1, NULL, NULL, 'BCA', '50000', '2022-11-26', 'B.Sc', NULL, 'dfsdfsad', 'sdfsdf', 'dfsdfsd', '2022-11-17', '2022-11-24', 0, 0, 0, '2022-11-22 12:22:44', '2022-11-22 12:22:44'),
(2, '2', 1, NULL, NULL, 'BCA', '50000', '2022-11-25', 'B.Sc', NULL, 'tert', 'ertert', 'rtertert', '2022-11-17', '2022-11-25', 0, 0, 0, '2022-11-22 12:32:13', '2022-11-22 12:32:13'),
(3, '4', 1, NULL, NULL, 'BCA', '50000', '2022-11-23', 'M.sc', NULL, '', '', 'sdfsdf', '2022-11-16', '2022-11-18', 0, 0, 0, '2022-11-22 12:33:32', '2022-11-22 12:33:32'),
(4, '1', 1, NULL, NULL, 'BCA', '50000', '2022-11-25', 'B.Sc', NULL, '', '', 'vdfgdfg', '2022-11-18', '2022-11-25', 0, 0, 0, '2022-11-22 12:37:07', '2022-11-22 12:37:07'),
(5, '3', 1, NULL, NULL, 'BCA', '50000', '2022-12-02', 'B.Sc', NULL, '', '', 'dsdfsdf', '2022-11-23', '2022-11-26', 0, 0, 0, '2022-11-22 12:39:35', '2022-11-22 12:39:35'),
(6, '4', 1, NULL, NULL, 'BCA', '50000', '2022-11-18', 'M.sc', NULL, '', '', 'dfsdfsd', '2022-11-18', '', 0, 0, 0, '2022-11-22 12:44:30', '2022-11-22 12:44:30');

-- --------------------------------------------------------

--
-- Table structure for table `investment_entry`
--

CREATE TABLE `investment_entry` (
  `investment_entry_id` int(11) NOT NULL,
  `voucher_ref` varchar(255) DEFAULT NULL,
  `donor_name` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `pan_number` varchar(255) DEFAULT NULL,
  `date_of_entry` varchar(255) DEFAULT NULL,
  `debit_ledger` varchar(255) DEFAULT NULL,
  `credit_ledger` varchar(255) DEFAULT NULL,
  `debit_amount` varchar(255) DEFAULT NULL,
  `credit_amount` varchar(255) DEFAULT NULL,
  `narration` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `insert_login_id` int(11) DEFAULT NULL,
  `update_login_id` int(11) DEFAULT NULL,
  `delete_login_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `investment_entry`
--

INSERT INTO `investment_entry` (`investment_entry_id`, `voucher_ref`, `donor_name`, `contact_number`, `pan_number`, `date_of_entry`, `debit_ledger`, `credit_ledger`, `debit_amount`, `credit_amount`, `narration`, `status`, `insert_login_id`, `update_login_id`, `delete_login_id`, `created_date`, `updated_date`) VALUES
(1, 'VIE-1/Nov22', '6', '2222222222', 'wresdfsd43434', '2022-02-13', 'SBI', '                                    Prem', '20000', '20000', '', 1, 1, 1, 1, '2022-11-18 17:14:06', '2022-11-18 17:14:06'),
(2, 'VIE-2/Nov22', '7', '3333333333', 'ewr3dffefw', '1222-12-12', 'SBI', '                                    Mukesh', '10000', '10000', '', 0, 1, NULL, NULL, '2022-11-18 17:30:03', '2022-11-18 17:30:03');

-- --------------------------------------------------------

--
-- Table structure for table `ledger`
--

CREATE TABLE `ledger` (
  `ledgerid` int(11) NOT NULL,
  `ledgername` varchar(255) DEFAULT NULL,
  `groupname` varchar(255) DEFAULT NULL,
  `subgroupname` varchar(255) DEFAULT NULL,
  `inventory` varchar(255) DEFAULT NULL,
  `costcentre` varchar(255) DEFAULT NULL,
  `openingbalancedr` varchar(200) DEFAULT NULL,
  `opening_credit` varchar(255) DEFAULT NULL,
  `opening_debit` varchar(255) DEFAULT NULL,
  `openingbalance` int(200) DEFAULT 0,
  `status` varchar(255) DEFAULT '0',
  `exciseduty` varchar(255) DEFAULT NULL,
  `pan` varchar(255) DEFAULT NULL,
  `tin` varchar(255) DEFAULT NULL,
  `servicetax` varchar(255) DEFAULT NULL,
  `contactperson` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `address3` varchar(255) DEFAULT NULL,
  `address4` varchar(255) DEFAULT NULL,
  `contactnumber` varchar(255) DEFAULT NULL,
  `AccountRefId` int(11) DEFAULT NULL,
  `ServiceTaxNumber` varchar(255) DEFAULT NULL,
  `ExciseDutyReg` varchar(255) DEFAULT NULL,
  `DebitCredit` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ledger`
--

INSERT INTO `ledger` (`ledgerid`, `ledgername`, `groupname`, `subgroupname`, `inventory`, `costcentre`, `openingbalancedr`, `opening_credit`, `opening_debit`, `openingbalance`, `status`, `exciseduty`, `pan`, `tin`, `servicetax`, `contactperson`, `address1`, `address2`, `address3`, `address4`, `contactnumber`, `AccountRefId`, `ServiceTaxNumber`, `ExciseDutyReg`, `DebitCredit`) VALUES
(3, 'SBI', '3', '17', 'No', 'No', 'CR', '0', '0', 0, '0', '', '', '', '', '', '', '', '', '', '', 17, NULL, NULL, NULL),
(4, 'Mukesh', '3', '3', 'No', 'No', 'CR', '50000', '0', 50000, '0', '', '', '', '', '', '', '', '', '', '', 3, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `minimum_requirement`
--

CREATE TABLE `minimum_requirement` (
  `minimum_requirement_id` int(11) NOT NULL,
  `minimum_requirement_name` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `minimum_requirement`
--

INSERT INTO `minimum_requirement` (`minimum_requirement_id`, `minimum_requirement_name`, `status`, `created_date`, `updated_date`) VALUES
(1, '10th', 0, '2022-11-17 10:53:13', '2022-11-17 10:53:13');

-- --------------------------------------------------------

--
-- Table structure for table `payment_entry`
--

CREATE TABLE `payment_entry` (
  `payment_entry_id` int(11) NOT NULL,
  `voucher_ref` varchar(255) DEFAULT NULL,
  `institute_name` varchar(255) DEFAULT NULL,
  `applicant_name` varchar(255) DEFAULT NULL,
  `balance_installment` varchar(255) DEFAULT NULL,
  `date_of_entry` varchar(255) DEFAULT NULL,
  `debit_ledger` varchar(255) DEFAULT NULL,
  `credit_ledger` varchar(255) DEFAULT NULL,
  `debit_amount` varchar(255) DEFAULT NULL,
  `credit_amount` varchar(255) DEFAULT NULL,
  `narration` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `insert_login_id` int(11) DEFAULT NULL,
  `update_login_id` int(11) DEFAULT NULL,
  `delete_login_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment_entry`
--

INSERT INTO `payment_entry` (`payment_entry_id`, `voucher_ref`, `institute_name`, `applicant_name`, `balance_installment`, `date_of_entry`, `debit_ledger`, `credit_ledger`, `debit_amount`, `credit_amount`, `narration`, `status`, `insert_login_id`, `update_login_id`, `delete_login_id`, `created_date`, `updated_date`) VALUES
(1, 'VPE-1/Nov22', '1', '2', '', '2000-02-10', '                                    test', '17', '10000', '10000', '', 1, 1, 1, 1, '2022-11-19 16:05:04', '2022-11-19 16:05:04'),
(2, 'VPE-2/Nov22', '1', '2', '', '2000-11-11', '                                    test', '17', '10000', '10000', '', 0, 1, NULL, NULL, '2022-11-19 19:11:01', '2022-11-19 19:11:01');

-- --------------------------------------------------------

--
-- Table structure for table `purpose`
--

CREATE TABLE `purpose` (
  `purposeid` int(11) NOT NULL,
  `purposename` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `purpose`
--

INSERT INTO `purpose` (`purposeid`, `purposename`, `status`) VALUES
(1, 'test', 0);

-- --------------------------------------------------------

--
-- Table structure for table `seeker_registration`
--

CREATE TABLE `seeker_registration` (
  `seeker_id` int(11) NOT NULL,
  `applicant_name` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `address1` text DEFAULT NULL,
  `address2` text DEFAULT NULL,
  `address3` date DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `seeker_registration`
--

INSERT INTO `seeker_registration` (`seeker_id`, `applicant_name`, `contact_number`, `address1`, `address2`, `address3`, `place`, `pincode`, `email_id`, `user_name`, `password`, `status`, `created_date`, `updated_date`) VALUES
(1, 'tet', '3423432432', 'Car Street', '', '0000-00-00', 'test', '342342', 'test@gmail.com', 'test@gmail.com', '3423432432', 0, '2022-11-07 17:55:48', '2022-11-07 17:55:48'),
(2, 'tet', '3243243243', 'Car Street', '', '0000-00-00', 'test', '342342', 'test@gmail.com', 'test@gmail.com', '3243243243', 0, '2022-11-07 18:32:04', '2022-11-07 18:32:04'),
(3, 'tet', '3243243243', 'Car Street', '', '0000-00-00', 'test', '342342', 'test@gmail.com', 'test@gmail.com', '3243243243', 0, '2022-11-07 18:33:45', '2022-11-07 18:33:45'),
(4, 'tet', '3424324234', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '3424324234', 0, '2022-11-07 18:33:55', '2022-11-07 18:33:55'),
(5, 'tet', '3242342342', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '3242342342', 0, '2022-11-07 18:37:22', '2022-11-07 18:37:22'),
(6, 'tet', '3423423423', 'Car Street', '', '0000-00-00', 'test', '234324', 'test@gmail.com', 'test@gmail.com', '3423423423', 0, '2022-11-07 18:39:11', '2022-11-07 18:39:11'),
(7, 'tet', '4234234234', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '4234234234', 0, '2022-11-07 18:41:11', '2022-11-07 18:41:11'),
(8, 'tet', '4234234234', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '4234234234', 0, '2022-11-07 18:42:00', '2022-11-07 18:42:00'),
(9, 'tet', '3423423424', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '3423423424', 0, '2022-11-07 18:42:29', '2022-11-07 18:42:29'),
(10, 'tet', '3423423424', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '3423423424', 0, '2022-11-07 18:42:47', '2022-11-07 18:42:47'),
(11, 'tet', '3423423424', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '3423423424', 0, '2022-11-07 18:43:06', '2022-11-07 18:43:06'),
(12, 'tet', '3423423424', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '3423423424', 0, '2022-11-07 18:43:17', '2022-11-07 18:43:17'),
(13, 'tet', '3423423424', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '3423423424', 0, '2022-11-07 18:43:38', '2022-11-07 18:43:38'),
(14, 'tet', '3423423424', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '3423423424', 0, '2022-11-07 18:43:53', '2022-11-07 18:43:53'),
(15, 'tet', '3423423424', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '3423423424', 0, '2022-11-07 18:44:06', '2022-11-07 18:44:06'),
(16, 'tet', '3423423424', 'Car Street', '', '0000-00-00', 'test', '234234', 'test@gmail.com', 'test@gmail.com', '3423423424', 0, '2022-11-07 18:44:21', '2022-11-07 18:44:21'),
(17, 'siva', '5454787854', 'test', 'test1', '0000-00-00', 'test', '656698', 'test@gmail.com', '', '', 0, '2022-11-16 14:13:04', '2022-11-16 14:13:04');

-- --------------------------------------------------------

--
-- Table structure for table `staff_creation`
--

CREATE TABLE `staff_creation` (
  `staff_id` int(11) NOT NULL,
  `staff_name` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `address1` text DEFAULT NULL,
  `address2` text DEFAULT NULL,
  `address3` text DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `in_committee` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `ifsc_code` varchar(255) DEFAULT NULL,
  `account_holder_name` varchar(255) DEFAULT NULL,
  `staff_image` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `insert_login_id` int(11) DEFAULT NULL,
  `update_login_id` int(11) DEFAULT NULL,
  `delete_login_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff_creation`
--

INSERT INTO `staff_creation` (`staff_id`, `staff_name`, `department`, `address1`, `address2`, `address3`, `place`, `pincode`, `contact_person`, `contact_number`, `email_id`, `in_committee`, `account_number`, `bank_name`, `ifsc_code`, `account_holder_name`, `staff_image`, `status`, `insert_login_id`, `update_login_id`, `delete_login_id`, `created_date`, `updated_date`) VALUES
(1, 'Barath', 'HR', 'Car Street', '', '', 'Chennai', '324234', 'testset', '2342342342', 'test@gmail.com', 'Yes', '23432432443', 'test', 'IFDG0123456', 'test', '', 0, 1, NULL, NULL, '2022-11-17 16:24:49', '2022-11-17 16:24:49');

-- --------------------------------------------------------

--
-- Table structure for table `trustee_creation`
--

CREATE TABLE `trustee_creation` (
  `trustee_id` int(11) NOT NULL,
  `trustee_name` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `address1` text DEFAULT NULL,
  `address2` text DEFAULT NULL,
  `address3` text DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `pan_number` varchar(255) DEFAULT NULL,
  `trustee_image` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `insert_login_id` int(11) DEFAULT NULL,
  `update_login_id` int(11) DEFAULT NULL,
  `delete_login_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trustee_creation`
--

INSERT INTO `trustee_creation` (`trustee_id`, `trustee_name`, `contact_number`, `address1`, `address2`, `address3`, `place`, `pincode`, `email_id`, `pan_number`, `trustee_image`, `status`, `insert_login_id`, `update_login_id`, `delete_login_id`, `created_date`, `updated_date`) VALUES
(1, 'Raj', '3242342342', 'Car Street', '', '', 'Chennai', '234234', 'test@gmail.com', 'ABCDE1234F', '', 0, 1, 1, NULL, '2022-11-17 10:45:37', '2022-11-17 10:45:37'),
(2, 'siva', '3424234234', 'Car Street33', '', '', 'test12', '234324', 'test@gmail.com', 'ABCDE1234F', 'check.png', 0, NULL, 1, NULL, '2022-11-05 17:51:28', '2022-11-05 17:51:28'),
(3, '', '', '', '', '', '', '', '', '', '', 0, NULL, NULL, NULL, '2022-11-09 16:35:27', '2022-11-09 16:35:27');

-- --------------------------------------------------------

--
-- Table structure for table `trust_creation`
--

CREATE TABLE `trust_creation` (
  `trust_id` int(11) NOT NULL,
  `trust_name` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `address1` text DEFAULT NULL,
  `address2` text DEFAULT NULL,
  `address3` text DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `pan_number` varchar(255) DEFAULT NULL,
  `tan_number` varchar(255) DEFAULT NULL,
  `trust_logo` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `insert_login_id` int(11) DEFAULT NULL,
  `update_login_id` int(11) DEFAULT NULL,
  `delete_login_id` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trust_creation`
--

INSERT INTO `trust_creation` (`trust_id`, `trust_name`, `contact_person`, `contact_number`, `address1`, `address2`, `address3`, `place`, `pincode`, `email_id`, `website`, `pan_number`, `tan_number`, `trust_logo`, `status`, `insert_login_id`, `update_login_id`, `delete_login_id`, `created_date`, `updated_date`) VALUES
(1, 'Agaram', 'Surya', '1212121212', 'Car Street', '', '', 'Chennai', '232323', '', '', '', '', '', 0, 1, NULL, NULL, '2022-11-17 10:34:20', '2022-11-17 10:34:20'),
(2, 'madhu', 'banu', '1322132323', 'Address 1', '', '', 'pondy', '232323', '', '', '', '', '', 1, 1, NULL, 1, '2022-11-21 11:43:18', '2022-11-21 11:43:18'),
(3, 'madhu', 'banu', '5445454545', 'Address 1', 'Address 2', 'address3', 'pondy', '605004', 'sivashankari2903@gmail.com', 'www.abd.in', '', '', 'check.png', 0, 1, NULL, NULL, '2022-11-21 12:16:17', '2022-11-21 12:16:17'),
(4, 'banu', 'banu', '9865656565', 'Address 4', 'Address 2', 'address3', 'pondy', '605004', 'sivashankari2903@gmail.com', 'www.abd.in', '', '', 'check.png', 0, 1, 1, NULL, '2022-11-21 14:41:08', '2022-11-21 14:41:08'),
(5, 'Anu', 'banu', '9865652323', 'Address 1', 'Address 2', 'address3', 'pondy', '605004', 'sivashankari2903@gmail.com', 'www.abd.in', '', '', 'check.png', 0, 1, 1, NULL, '2022-11-21 16:33:58', '2022-11-21 16:33:58');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `emailid` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_password` varchar(255) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL,
  `status` varchar(255) DEFAULT '0',
  `Createddate` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `firstname`, `lastname`, `fullname`, `title`, `emailid`, `user_name`, `user_password`, `role`, `status`, `Createddate`) VALUES
(1, 'Super', 'Admin', 'Super Admin', 'Super Admin', 'support@feathertechnology.in', 'support@feathertechnology.in', 'admin@123', '1', '0', '2021-04-17 17:08:00'),
(18, 'Admin2', 'admin', 'Super Admin2', 'test', 'test@gmil.com', 'test@gmail.com', 'test@123', '1', '0', '2022-11-09 11:19:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accountsgroup`
--
ALTER TABLE `accountsgroup`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `bankmaster`
--
ALTER TABLE `bankmaster`
  ADD PRIMARY KEY (`bankid`);

--
-- Indexes for table `committee_creation`
--
ALTER TABLE `committee_creation`
  ADD PRIMARY KEY (`committee_id`);

--
-- Indexes for table `committee_review`
--
ALTER TABLE `committee_review`
  ADD PRIMARY KEY (`committee_review_id`);

--
-- Indexes for table `confirmation`
--
ALTER TABLE `confirmation`
  ADD PRIMARY KEY (`confirmation_id`);

--
-- Indexes for table `costcentre`
--
ALTER TABLE `costcentre`
  ADD PRIMARY KEY (`costcentreid`);

--
-- Indexes for table `course_category`
--
ALTER TABLE `course_category`
  ADD PRIMARY KEY (`course_category_id`);

--
-- Indexes for table `course_creation`
--
ALTER TABLE `course_creation`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `department_creation`
--
ALTER TABLE `department_creation`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `donator_creation`
--
ALTER TABLE `donator_creation`
  ADD PRIMARY KEY (`donator_id`);

--
-- Indexes for table `initiate_application`
--
ALTER TABLE `initiate_application`
  ADD PRIMARY KEY (`application_id`);

--
-- Indexes for table `institute_creation`
--
ALTER TABLE `institute_creation`
  ADD PRIMARY KEY (`institute_id`);

--
-- Indexes for table `institute_review`
--
ALTER TABLE `institute_review`
  ADD PRIMARY KEY (`institute_review_id`);

--
-- Indexes for table `investment_entry`
--
ALTER TABLE `investment_entry`
  ADD PRIMARY KEY (`investment_entry_id`);

--
-- Indexes for table `ledger`
--
ALTER TABLE `ledger`
  ADD PRIMARY KEY (`ledgerid`);

--
-- Indexes for table `minimum_requirement`
--
ALTER TABLE `minimum_requirement`
  ADD PRIMARY KEY (`minimum_requirement_id`);

--
-- Indexes for table `payment_entry`
--
ALTER TABLE `payment_entry`
  ADD PRIMARY KEY (`payment_entry_id`);

--
-- Indexes for table `purpose`
--
ALTER TABLE `purpose`
  ADD PRIMARY KEY (`purposeid`);

--
-- Indexes for table `seeker_registration`
--
ALTER TABLE `seeker_registration`
  ADD PRIMARY KEY (`seeker_id`);

--
-- Indexes for table `staff_creation`
--
ALTER TABLE `staff_creation`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `trustee_creation`
--
ALTER TABLE `trustee_creation`
  ADD PRIMARY KEY (`trustee_id`);

--
-- Indexes for table `trust_creation`
--
ALTER TABLE `trust_creation`
  ADD PRIMARY KEY (`trust_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accountsgroup`
--
ALTER TABLE `accountsgroup`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `bankmaster`
--
ALTER TABLE `bankmaster`
  MODIFY `bankid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `committee_creation`
--
ALTER TABLE `committee_creation`
  MODIFY `committee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `committee_review`
--
ALTER TABLE `committee_review`
  MODIFY `committee_review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `confirmation`
--
ALTER TABLE `confirmation`
  MODIFY `confirmation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `costcentre`
--
ALTER TABLE `costcentre`
  MODIFY `costcentreid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `course_category`
--
ALTER TABLE `course_category`
  MODIFY `course_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `course_creation`
--
ALTER TABLE `course_creation`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `department_creation`
--
ALTER TABLE `department_creation`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `donator_creation`
--
ALTER TABLE `donator_creation`
  MODIFY `donator_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `initiate_application`
--
ALTER TABLE `initiate_application`
  MODIFY `application_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `institute_creation`
--
ALTER TABLE `institute_creation`
  MODIFY `institute_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `institute_review`
--
ALTER TABLE `institute_review`
  MODIFY `institute_review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `investment_entry`
--
ALTER TABLE `investment_entry`
  MODIFY `investment_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ledger`
--
ALTER TABLE `ledger`
  MODIFY `ledgerid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `minimum_requirement`
--
ALTER TABLE `minimum_requirement`
  MODIFY `minimum_requirement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment_entry`
--
ALTER TABLE `payment_entry`
  MODIFY `payment_entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `purpose`
--
ALTER TABLE `purpose`
  MODIFY `purposeid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `seeker_registration`
--
ALTER TABLE `seeker_registration`
  MODIFY `seeker_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `staff_creation`
--
ALTER TABLE `staff_creation`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `trustee_creation`
--
ALTER TABLE `trustee_creation`
  MODIFY `trustee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `trust_creation`
--
ALTER TABLE `trust_creation`
  MODIFY `trust_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php 
@session_start();

if(isset($_SESSION['fullname'])){
	$fullname  = $_SESSION['fullname'];
}
if(isset($_SESSION['userid'])){
	$userid  = $_SESSION['userid'];
}

$msc=0;
if(isset($_GET['msc']))
{
	$msc=$_GET['msc'];
}
$current_page = isset($_GET['page']) ? $_GET['page'] : null; 
define('iEditValid', 1);
include('api/main.php'); // Database Connection File   
?>

<!doctype html>
<html lang="en">

<!-- downlaod customer excel div -->
<div id="backup_customer" style="display:none"></div>
<div id="accountdata" style="display:none"></div>
<!-- end customer excel div -->

<!-- Important -->
<?php  if( $current_page != 'vendorcreation' and $current_page != 'auction_details' ) { ?>
<?php include "include/common/dashboardhead.php"?>
<?php  } ?>


<?php if($current_page == 'vendorcreation') { ?>
<?php include "include/common/dashboardfinancedatatablehead.php"?>
<?php } ?>
<?php if($current_page == 'auction_details') { ?>
<?php include "include/common/dashboardfinancedatatablehead.php"?>
<?php } ?>

<body>
	<!-- Page wrapper start -->
	<div class="page-wrapper">
		<?php 
		if($_SESSION['userid']=="")
		{
			echo "<script>location.href='index.php'</script>"; 
		}
		include "include/common/leftbar.php"?>

		<!-- Page content start  -->
		<div class="page-content">

			<!-- Header start -->
			<header class="header">
				<div class="toggle-btns">
					<a id="toggle-sidebar" href="#">
						<i class="icon-list"></i>
					</a>
					<a id="pin-sidebar" href="#">
						<i class="icon-list"></i>
					</a>
				</div>
				<div class="header-items">
					<!-- Custom search start -->
					<div class="custom-search">
						<input type="text" class="search-query" placeholder="Search here ..." >
						<i class="icon-search1"></i>
					</div>
					<!-- Custom search end -->

					<!-- Header actions start -->
					<ul class="header-actions">
						<li class="dropdown"></li>
						<li class="dropdown">
							<a href="#" id="notifications" data-toggle="dropdown" aria-haspopup="true">
								<i class="icon-bell"></i>
								<span
									class="count-label"><?php //echo count($notification); // count($notificationmax); ?></span>
							</a>
							<div class="dropdown-menu dropdown-menu-right lrg" aria-labelledby="notifications">
								<div class="dropdown-menu-header">
									Notifications
								</div>
								<div class="customScroll5 quickscard">
									<ul class="header-notifications"></ul>
								</div>
							</div>
						</li>
						<li class="dropdown">
							<a href="#" id="userSettings" class="user-settings" data-toggle="dropdown"
								aria-haspopup="true">
								<span class="user-name"><?php echo $fullname; ?></span>
								<span class="avatar">
									<img src="img/user22.png" alt="avatar">
									<span class="status busy"></span>
								</span>
							</a>
							<div class="dropdown-menu dropdown-menu-right" aria-labelledby="userSettings">
								<div class="header-profile-actions">
									<div class="header-user-profile">
										<div class="header-user">
											<img src="img/user22.png" alt="Admin Template">
										</div>
										<h5><?php echo $fullname; ?></h5>
										<p><?php echo $fullname; ?></p>
									</div>
									<a href="#"><i class="icon-user1"></i> My Profile</a>
									<a href="logout.php"><i class="icon-log-out1"></i> Sign Out</a>
								</div>
							</div>
						</li>
					</ul>
					<!-- Header actions end -->
				</div>
			</header>
			<!-- Header end -->

			<!-- Trust Creation -->
			<?php if($current_page == 'trust_creation') { ?>
			<?php include "include/templates/trust_creation.php" ?>
			<?php } ?>

			<?php if($current_page == 'edit_trust_creation') { ?>
			<?php include "include/templates/edit_trust_creation.php" ?>
			<?php } ?>
			<!-- Staff Creation -->
			<?php if($current_page == 'staff_creation') { ?>
			<?php include "include/templates/staff_creation.php" ?>
			<?php } ?>

			<?php if($current_page == 'editstaff_creation') { ?>
			<?php include "include/templates/editstaff_creation.php" ?>
			<?php } ?>

			
			<!-- Trustee Creation -->
			<?php if($current_page == 'trustee_creation') { ?>
			<?php include "include/templates/trustee_creation.php" ?>
			<?php } ?>

			<?php if($current_page == 'edit_trustee_creation') { ?>
			<?php include "include/templates/edit_trustee_creation.php" ?>
			<?php } ?>

			<!-- Seeker Registration -->
			<?php if($current_page == 'seeker_registration') { ?>
			<?php include "include/templates/seeker_registration.php" ?>
			<?php } ?>

			<!-- Manage User -->
			<?php if($current_page == 'manage_users') { ?>
			<?php include "include/templates/manage_users.php" ?>
			<?php } ?>

			<!-- Course Creation -->
			<?php if($current_page == 'course_creation') { ?>
			<?php include "include/templates/course_creation.php" ?>
			<?php } ?>

			<?php if($current_page == 'edit_course_creation') { ?>
			<?php include "include/templates/edit_course_creation.php" ?>
			<?php } ?>

			<!-- Institute Creation -->
			<?php if($current_page == 'institute_creation') { ?>
			<?php include "include/templates/institute_creation.php" ?>
			<?php } ?>

			<?php if($current_page == 'edit_institute_creation') { ?>
			<?php include "include/templates/edit_institute_creation.php" ?>
			<?php } ?>
			<!-- Institute Creation -->
			<?php if($current_page == 'committee_creation') { ?>
			<?php include "include/templates/committee_creation.php" ?>
			<?php } ?>

			<?php if($current_page == 'edit_committee_creation') { ?>
			<?php include "include/templates/edit_committee_creation.php" ?>
			<?php } ?>

			<!-- Institute creation -->
			<?php if($current_page == 'donator_creation') { ?>
			<?php include "include/templates/donator_creation.php" ?>
			<?php } ?>

			<?php if($current_page == 'edit_donator_creation') { ?>
			<?php include "include/templates/edit_donator_creation.php" ?>
			<?php } ?>

			<!-- Finance creation -->
			<?php if($current_page == 'finance_creation') { ?>
			<?php include "include/templates/finance_creation.php" ?>
			<?php } ?>

			<!-- Bank creation -->
			<?php if($current_page == 'bank_creation') { ?>
			<?php include "include/templates/bank_creation.php" ?>
			<?php } ?>

			<?php if($current_page == 'editbank') { ?>
			<?php include "include/templates/editbank.php" ?>
			<?php } ?>

			<!-- Initiate Application -->
			<?php if($current_page == 'initiate_application') { ?>
			<?php include "include/templates/initiate_application.php" ?>
			<?php } ?>

			<?php if($current_page == 'edit_initiate_application') { ?>
			<?php include "include/templates/edit_initiate_application.php" ?>
			<?php } ?>

			<!-- Committee Review -->
			<?php if($current_page == 'committee_review') { ?>
			<?php include "include/templates/committee_review.php" ?>
			<?php } ?>

			<?php if($current_page == 'edit_committee_review') { ?>
			<?php include "include/templates/edit_committee_review.php" ?>
			<?php } ?>

			<!-- Institite Review -->
			<?php if($current_page == 'institute_review') { ?>
			<?php include "include/templates/institute_review.php" ?>
			<?php } ?>

			<?php if($current_page == 'edit_institute_review') { ?>
			<?php include "include/templates/edit_institute_review.php" ?>
			<?php } ?>

			<!-- Confirmation -->
			<?php if($current_page == 'confirmation') { ?>
			<?php include "include/templates/confirmation.php" ?>
			<?php } ?>

			<!-- Confirmation -->
			<?php if($current_page == 'edit_confirmation') { ?>
			<?php include "include/templates/edit_confirmation.php" ?>
			<?php } ?>

			<!--  Candidate Details -->
			<?php if($current_page == 'candidate_details') { ?>
			<?php include "include/templates/candidate_details.php" ?>
			<?php } ?>

			<?php if($current_page == 'edit_candidate_details') { ?>
			<?php include "include/templates/edit_candidate_details.php" ?>
			<?php } ?>


			<!--  Candidate Details -->
			<?php if($current_page == 'course_completion') { ?>
			<?php include "include/templates/course_completion.php" ?>
			<?php } ?>

				<?php if($current_page == 'edit_course_completion') { ?>
			<?php include "include/templates/edit_course_completion.php" ?>
			<?php } ?>

			<!--  Candidate Details -->
			<?php if($current_page == 'liability_creation') { ?>
			<?php include "include/templates/liability_creation.php" ?>
			<?php } ?>

			<!--  Investment Entry -->
			<?php if($current_page == 'investment_entry') { ?>
			<?php include "include/templates/investment_entry.php" ?>
			<?php } ?>
			
			<?php if($current_page == 'edit_investment_entry') { ?>
			<?php include "include/templates/edit_investment_entry.php" ?>
			<?php } ?>

			<!--  Payment Entry -->
			<?php if($current_page == 'payment_entry') { ?>
			<?php include "include/templates/payment_entry.php" ?>
			<?php } ?>

			<?php if($current_page == 'edit_payment_entry') { ?>
			<?php include "include/templates/edit_payment_entry.php" ?>
			<?php } ?>

			<!--  Investment Details -->
			<?php if($current_page == 'investment_details') { ?>
			<?php include "include/templates/investment_details.php" ?>
			<?php } ?>

			<!--  Fund Movement -->
			<?php if($current_page == 'monthly_fund_movement') { ?>
			<?php include "include/templates/monthly_fund_movement.php" ?>
			<?php } ?>

			<!--  General Message -->
			<?php if($current_page == 'general_message') { ?>
			<?php include "include/templates/general_message.php" ?>
			<?php } ?>

		</div>
		<!-- Page content end -->

	</div>
	<!-- Page wrapper end -->

	<!-- Important -->
	<!-- This the important section for download excel file and script adding with our screen -->
	<?php if( $current_page != 'vendorcreation') { ?>
	<?php include "include/common/dashboardfooter.php"?>
	<?php } ?>

	<?php
		if($current_page == 'vendorcreation') { ?>
	<?php include "include/common/dashboardfinancedatatablefooter.php" ?>
	<?php } ?>
	
	
</body>
</html>
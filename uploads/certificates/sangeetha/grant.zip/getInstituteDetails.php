<?php
@session_start();
include 'ajaxconfig.php';

if(isset($_SESSION["userid"])){
    $userid = $_SESSION["userid"];
}
if(isset($_POST["course_id"])){
	$course_id = $_POST["course_id"];
}

$minimum_requirement = array();
$minimum_requirement_id = array();
$minimum_requirement_name = array();
$institute_id = array();
$institute_name = array();
$course_duration = '';
$course_fees = '';

// get minimum requirement name
$getMinReq=$con->query("SELECT minimum_requirement,course_fees,course_duration FROM course_creation WHERE course_id = '".$course_id."' ");
while($row=$getMinReq->fetch_assoc()){
    $minimum_requirements    = $row["minimum_requirement"];
    $course_duration    = $row["course_duration"];
    $course_fees    = $row["course_fees"];
}

$minimum_requirement = explode(',',$minimum_requirements);
foreach($minimum_requirement as $value)
{
    $getMinReqName=$con->query("SELECT minimum_requirement_name, minimum_requirement_id FROM minimum_requirement WHERE minimum_requirement_id = '".$value."' ");
    while($row1=$getMinReqName->fetch_assoc()){
        $minimum_requirement_id[]    = $row1["minimum_requirement_id"];
        $minimum_requirement_name[]    = $row1["minimum_requirement_name"];
    }
} 

// get institute name
$getInstName=$con->query("SELECT institute_id, institute_name FROM institute_creation WHERE course_offered LIKE '%".$course_id."%' ");
while($row2=$getInstName->fetch_assoc()){
    $institute_id[]    = $row2["institute_id"];
    $institute_name[]    = $row2["institute_name"];
}

$minimumrequirementName["institute_id"] = $institute_id;
$minimumrequirementName["institute_name"] = $institute_name;

$minimumrequirementName["minimum_requirement_id"] = $minimum_requirement_id;
$minimumrequirementName["minimum_requirement_name"] = $minimum_requirement_name;

$minimumrequirementName["course_duration"] = $course_duration;
$minimumrequirementName["course_fees"] = $course_fees;
 
echo json_encode($minimumrequirementName);
?>
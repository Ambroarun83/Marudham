<?php
$HOSTPATH="http://".$_SERVER['HTTP_HOST']."/marudham/"; 
define('HOSTPATH',$HOSTPATH);
?>
